﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SdpProject.Models
{
    public class User
    {
        public int id { set; get; }

        public string name { set; get; }

        public string surname { set; get; }

        public string phone { set; get; }


    }
}
